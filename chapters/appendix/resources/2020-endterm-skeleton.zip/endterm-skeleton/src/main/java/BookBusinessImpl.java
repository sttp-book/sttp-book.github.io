import java.util.ArrayList;
import java.util.List;

public class BookBusinessImpl {

    private final BookService bookService;
    private final EmailService emailService;

    public BookBusinessImpl(BookService bookService, EmailService emailService) {
        this.bookService = bookService;
        this.emailService = emailService;
    }

    /**
     * Retrieve all the titles of books of an author, filtered by a keyword
     * @param author the author's name
     * @param keyword keyword to filter
     * @return list of titles
     */
    public List<String> retrieveBooks(String author, String keyword) {
        List<String> filteredBooks = new ArrayList<>();
        List<String> allBooks = bookService.retrieveBooks(author);
        for (String bookTitle : allBooks) {
            if (bookTitle.contains(keyword)) {
                filteredBooks.add(bookTitle);
                bookService.updateLastVisualization(author, bookTitle);
            }
        }
        return filteredBooks;
    }

    /**
     * Deletes all books of a specific author that contain a keyword
     * @param author
     * @param keyword
     */
    public void deleteBooks(String author, String keyword) {
        List<String> allBooks = bookService.retrieveBooks(author);
        for (String bookTitle : allBooks) {
            if (bookTitle.contains(keyword)) {
                bookService.deleteBook(author, bookTitle);
            }
        }
    }

    /**
     * Creates a copy of the book, now with the new edition in the title.
     *
     * @param author name of the author
     * @param keyword keyword to search
     * @param edition number of the new edition
     */
    public void releaseNewEdition(String author, String keyword, int edition) {
        List<String> allBooks = bookService.retrieveBooks(author);
        for (String bookTitle : allBooks) {
            if (bookTitle.contains(keyword)) {
                bookService.addBook(author, bookTitle + " - edition " + edition);
            }
        }
    }

    /**
     * Move all books from one author to another.
     *
     * @param author original author
     * @param keyword keyword to search
     * @param destAuthor destination author
     */
    public void moveBooks(String author, String keyword, String destAuthor) {
        List<String> allBooks = bookService.retrieveBooks(author);
        for (String bookTitle : allBooks) {
            if (bookTitle.contains(keyword)) {
                bookService.moveBook(author, bookTitle, destAuthor);
            }
        }
    }

    /**
     * Sends a marketing email about all books of a specific author, with a given keyword.
     *
     * @param author
     * @param keyword
     */
    public void notifyPossibleBuyers(String author, String keyword) {
        List<String> allBooks = bookService.retrieveBooks(author);
        for (String bookTitle : allBooks) {
            if (bookTitle.contains(keyword)) {
                emailService.sendNotification(bookTitle);
            }
        }
    }

}
