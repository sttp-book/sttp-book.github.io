import java.util.List;

public interface BookService {

    List<String> retrieveBooks(String author);
    void deleteBook(String author, String bookTitle);
    void addBook(String author, String newBookTitle);
    void updateLastVisualization(String author, String bookTitle);
    void moveBook(String author, String bookTitle, String destAuthor);
}