public interface EmailService {
    void sendNotification(String message);
}
