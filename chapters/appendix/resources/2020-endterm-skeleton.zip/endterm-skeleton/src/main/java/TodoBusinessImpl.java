import java.util.ArrayList;
import java.util.List;
import java.util.Map;


public class TodoBusinessImpl {
    private TodoService todoService;
    private final EmailService emailService;

    public TodoBusinessImpl(TodoService todoService, EmailService emailService) {
        this.todoService = todoService;
        this.emailService = emailService;
    }

    /**
     * Searches all the ToDos related to a user. Select only todos that contain the keyword.
     * It also updates the last visualization date of that todo.
     *
     * @param user the name of the user
     * @param keyword keyword to be searched for
     * @return list of todos
     */
    public List<String> retrieveTodos(String user, String keyword) {
        List<String> filteredTodos = new ArrayList<>();
        List<String> allTodos = todoService.retrieveTodos(user);
        for (String todo : allTodos) {
            if (todo.contains(keyword)) {
                filteredTodos.add(todo);
                todoService.updateLastVisualization(user, todo);
            }
        }
        return filteredTodos;
    }

    /**
     * Deletes all ToDos that contain a specific keyword from a user
     *
     * @param user the name of the user
     * @param keyword the keyword
     */
    public void deleteToDos(String user, String keyword) {
        List<String> allTodos = todoService.retrieveTodos(user);
        for (String todo : allTodos) {
            if (todo.contains(keyword)) {
                todoService.deleteTodo(todo);
            }
        }
    }

    /**
     * Duplicates all todos that start with a keyword.
     * Adds a " - v2" to the copy.
     *
     * @param user the name of the user
     * @param keyword the keyword
     */
    public void duplicateToDos(String user, String keyword) {
        List<String> allTodos = todoService.retrieveTodos(user);
        for (String todo : allTodos) {
            if (todo.contains(keyword)) {
                todoService.addTodo(user, todo + " - v2");
            }
        }
    }

    /**
     * Moves all ToDos that contain a keyword from one user to another.
     *
     * @param user origin user
     * @param keyword keyword to search
     * @param destUser destination user
     */
    public void moveToDos(String user, String keyword, String destUser) {
        List<String> allTodos = todoService.retrieveTodos(user);
        for (String todo : allTodos) {
            if (todo.contains(keyword)) {
                todoService.moveTodo(user, todo, destUser);
            }
        }
    }

    /**
     * Sends notifications to all users that are inactive for more than 10
     * days.
     *
     * todoService.retrieveUsersAndDaysOfLastInteraction() returns a map that
     * contains the user name (key) and the number of days s/he is inactive (value)
     */
    public void sendNotificationsToInactiveUsers() {
        Map<String, Integer> users = todoService.retrieveUsersAndDaysOfLastInteraction();

        for (Map.Entry<String, Integer> entry : users.entrySet()) {
            String user = entry.getKey();
            int daysOfInactivity = entry.getValue();

            if(daysOfInactivity > 10) {
                emailService.sendNotification(user);
            }
        }
    }

}
