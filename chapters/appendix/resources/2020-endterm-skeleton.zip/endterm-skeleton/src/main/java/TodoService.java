import java.util.List;
import java.util.Map;

public interface TodoService {

    List<String> retrieveTodos(String user);
    void deleteTodo(String todo);

    Map<String, Integer> retrieveUsersAndDaysOfLastInteraction();
    void addTodo(String user, String newTodo);

    void updateLastVisualization(String user, String todo);

    void moveTodo(String user, String todo, String destUser);
}