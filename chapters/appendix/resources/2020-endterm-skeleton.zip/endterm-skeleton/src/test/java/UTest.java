import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.*;
import org.junit.jupiter.api.Assertions;

public class UTest {

    /**
     * Explain your tests!
     */
    @Test
    void t1() {
        assertThat(1+1).isEqualTo(2);
    }
}
