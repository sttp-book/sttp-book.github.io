import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;

public class UTest {

    /**
     * Explain your tests!
     */
    @Test
    void t1() {
        assertThat(1+1).isEqualTo(2);
    }
}
